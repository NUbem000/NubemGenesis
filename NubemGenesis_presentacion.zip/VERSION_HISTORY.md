# 🧾 Historial de versiones – NubemGenesisDeploy

Este documento muestra la evolución simbiótica del sistema NubemGenesisDeploy a través de sus versiones oficiales.

---

## 🔰 v1.0.0 – 2025-04-18

**Estado:** Publicado  
**Descripción:** Primera versión estable y funcional del sistema

### Componentes incluidos:
- Validación de entorno (`check_env.sh`)
- Validación Firestore (`validar_memoria_activa.py`)
- Despliegue manual (`deploy_nubemgenesis.sh`)
- Orquestador total (`run_nubemgenesis.sh`)
- Control de secretos (`git_clean_and_force_push.sh`)
- Primeros workflows de CI/CD (`deploy.yml`, `deploy_full.yml`)
- Documentación general y simbólica

---

## ⚙️ v1.1.0 – 2025-04-19

**Estado:** Finalizado  
**Descripción:** Versión extendida con visualización simbólica, documentación automática y test de memoria activa.

### Componentes nuevos:
- `docs_autogen.py` – Generador de documentación viva
- `docs_relaciones_autohtml.py` – Diagrama Mermaid + HTML interactivo
- `test_memoria.sh` – Test automático de validación simbiótica de Firestore
- `estado.sh` – Dashboard CLI de estado del sistema
- `README_diagrama.md` y `docs_menu.md` como documentación auxiliar
- `docs_autogen_full.yml` – Workflow para documentación y diagramas
- Integración del pre-commit y badge de estado

---

## 🔮 v2.0.0 – [Planificación en curso]

**Estado:** Próxima fase (simbiótica y evolutiva)

### Objetivos estratégicos:
- Dashboards visuales en tiempo real
- Módulos IA con conexión GPT (plugin autoconectable)
- Configuración 100% dinámica vía `config.yaml`
- Activación simbiótica desde web (interfaz NubemGenesis)
- Gestión de proyectos multiusuario

---

## 🧠 Autoría simbiótica

David Anguera – CEO NubemSystems  
NubemGenesis IA – copiloto generativo y curador simbiótico

---