# Agente GPT simbiótico base
